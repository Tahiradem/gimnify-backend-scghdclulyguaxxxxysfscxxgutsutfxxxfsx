const express = require('express');
const axios = require('axios');
const path = require('path');

const app = express();
const PORT = 3000;

// 🔐 Hardcoded AfroMessage Config (Insert your actual credentials here)
const AFRO_TOKEN = 'your_token_here';
const AFRO_FROM = 'your_identifier_id';
const AFRO_SENDER = 'your_sender_name';
const AFRO_CALLBACK = 'https://yourdomain.com/sms-status';

// Middleware
app.use(express.urlencoded({ extended: true }));

// Serve static HTML
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle SMS sending
app.post('/send-sms', async (req, res) => {
  const { to, message } = req.body;

  const baseUrl = 'https://api.afromessage.com/api/send';
  const params = new URLSearchParams({
    from: AFRO_FROM,
    sender: AFRO_SENDER,
    to,
    message,
    callback: AFRO_CALLBACK,
  });

  try {
    const response = await axios.get(`${baseUrl}?${params.toString()}`, {
      headers: {
        Authorization: `Bearer ${AFRO_TOKEN}`,
        'Content-Type': 'application/json',
      },
    });

    const { acknowledge, response: smsResponse } = response.data;

    if (acknowledge === 'success') {
      res.send(`<h2>✅ SMS sent successfully!</h2><pre>${JSON.stringify(smsResponse, null, 2)}</pre>`);
    } else {
      res.send(`<h2>❌ Failed to send SMS</h2><pre>${JSON.stringify(response.data, null, 2)}</pre>`);
    }
  } catch (error) {
    res.send(`<h2>⚠️ Error</h2><pre>${JSON.stringify(error.response?.data || error.message, null, 2)}</pre>`);
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Visit http://localhost:${PORT} to send a test SMS`);
});
